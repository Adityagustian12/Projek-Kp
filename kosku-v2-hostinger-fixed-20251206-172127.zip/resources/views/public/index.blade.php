<div>
    <!-- Do what you can, with what you have, where you are. - Theodore Roosevelt -->
</div>
