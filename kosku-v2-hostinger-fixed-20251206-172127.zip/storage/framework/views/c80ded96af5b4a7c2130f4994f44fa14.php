<?php $__env->startSection('title', 'Kelola Penghuni - Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar">
            <div class="p-3">
                <h6 class="text-muted text-uppercase mb-3">Menu Admin</h6>
                <nav class="nav flex-column">
                    <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="<?php echo e(route('admin.bookings')); ?>">
                        <i class="fas fa-calendar-check me-2"></i>Kelola Booking
                    </a>
                    <a class="nav-link" href="<?php echo e(route('admin.rooms')); ?>">
                        <i class="fas fa-bed me-2"></i>Kelola Kamar
                    </a>
                    <a class="nav-link" href="<?php echo e(route('admin.bills')); ?>">
                        <i class="fas fa-file-invoice me-2"></i>Kelola Tagihan
                    </a>
                    <a class="nav-link" href="<?php echo e(route('admin.payments')); ?>">
                        <i class="fas fa-credit-card me-2"></i>Kelola Pembayaran
                    </a>
                    <a class="nav-link" href="<?php echo e(route('admin.complaints')); ?>">
                        <i class="fas fa-exclamation-triangle me-2"></i>Kelola Keluhan
                    </a>
                    <a class="nav-link active" href="<?php echo e(route('admin.tenants')); ?>">
                        <i class="fas fa-users me-2"></i>Kelola Penghuni
                    </a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10 main-content">
            <div class="p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="mb-0">
                        <i class="fas fa-users me-2"></i>Kelola Penghuni
                    </h2>
                </div>


                <!-- Tenants Table -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i>Daftar Penghuni
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if($tenants->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Foto</th>
                                            <th>Nama</th>
                                            <th>Email</th>
                                            <th>Telepon</th>
                                            <th>Kamar</th>
                                            <th>Tanggal Masuk</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php if($tenant->profile_picture): ?>
                                                        <img src="<?php echo e(asset('storage/' . $tenant->profile_picture)); ?>" 
                                                             class="rounded-circle" 
                                                             width="40" height="40" 
                                                             alt="Foto <?php echo e($tenant->name); ?>">
                                                    <?php else: ?>
                                                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" 
                                                             style="width: 40px; height: 40px;">
                                                            <?php echo e(strtoupper(substr($tenant->name, 0, 1))); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div>
                                                        <strong><?php echo e($tenant->name); ?></strong>
                                                        <?php if($tenant->birth_date): ?>
                                                            <br>
                                                            <small class="text-muted"><?php echo e($tenant->birth_date->format('d M Y')); ?></small>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div>
                                                        <strong><?php echo e($tenant->email); ?></strong>
                                                        <?php if($tenant->address): ?>
                                                            <br>
                                                            <small class="text-muted"><?php echo e(Str::limit($tenant->address, 30)); ?></small>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo e($tenant->phone ?? '-'); ?>

                                                </td>
                                                <td>
                                                    <?php
                                                        $currentRoom = $tenant->bookings()
                                                            ->where('status', 'occupied')
                                                            ->with('room')
                                                            ->latest()
                                                            ->first();
                                                    ?>
                                                    <?php if($currentRoom): ?>
                                                        <span class="badge bg-info"><?php echo e($currentRoom->room->room_number); ?></span>
                                                        <br>
                                                        <small class="text-muted">Rp <?php echo e(number_format($currentRoom->room->price, 0, ',', '.')); ?>/bulan</small>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($currentRoom): ?>
                                                        <?php echo e($currentRoom->check_in_date->format('d M Y')); ?>

                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <button class="btn btn-sm btn-outline-info" onclick="viewTenant(<?php echo e($tenant->id); ?>)" title="Lihat Detail">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteTenant(<?php echo e($tenant->id); ?>)" title="Nonaktifkan Penghuni">
                                                            <i class="fas fa-user-slash"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination -->
                            <div class="d-flex justify-content-center mt-4">
                                <?php echo e($tenants->links()); ?>

                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-users fa-4x text-muted mb-3"></i>
                                <h4 class="text-muted">Belum ada penghuni</h4>
                                <p class="text-muted">Belum ada penghuni yang terdaftar di sistem.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Summary Cards (simplified) -->
                <?php if($tenants->count() > 0): ?>
                <div class="row mt-4">
                    <div class="col-md-6 col-lg-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="mb-0"><?php echo e($tenants->count()); ?></h4>
                                        <p class="mb-0">Total Penghuni</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-users fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="card bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="mb-0"><?php echo e($tenants->filter(function($tenant) { return $tenant->complaints()->exists(); })->count()); ?></h4>
                                        <p class="mb-0">Punya Keluhan</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-exclamation-triangle fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.sidebar {
    background-color: #f8f9fa;
    min-height: 100vh;
    border-right: 1px solid #dee2e6;
}

.main-content {
    background-color: #fff;
}

.nav-link {
    color: #495057;
    padding: 0.75rem 1rem;
    border-radius: 0.375rem;
    margin-bottom: 0.25rem;
}

.nav-link:hover {
    background-color: #e9ecef;
    color: #495057;
}

.nav-link.active {
    background-color: #0d6efd;
    color: white;
}

.table th {
    border-top: none;
    font-weight: 600;
    color: #495057;
}

.btn-group .btn {
    border-radius: 0.375rem;
    margin-right: 0.25rem;
}

.btn-group .btn:last-child {
    margin-right: 0;
}

.table img {
    object-fit: cover;
}
</style>

<script>
function viewTenant(tenantId) {
    // Redirect to tenant detail page
    window.location.href = `/admin/tenants/${tenantId}`;
}

// fungsi edit dan riwayat dihapus sesuai permintaan

function deleteTenant(tenantId) {
    if (confirm('⚠️ PERINGATAN: Apakah Anda yakin ingin menonaktifkan penghuni ini?\n\n' +
                'Tindakan ini akan:\n' +
                '• Menonaktifkan akun penghuni (data tidak hilang permanen)\n' +
                '• Otomatis menyelesaikan booking yang sedang aktif (kamar akan tersedia kembali)\n' +
                '• Membatalkan booking yang sudah dikonfirmasi tapi belum masuk kamar\n' +
                '• Menghapus booking yang masih pending\n' +
                '• Menghapus tagihan yang belum dibayar\n' +
                '• Menghapus keluhan yang belum selesai\n' +
                '• Mengubah role pengguna kembali menjadi "Pencari Kosan"\n\n' +
                '✅ Data yang DIPERTAHANKAN:\n' +
                '• Riwayat pembayaran yang sudah dibayar\n' +
                '• Booking yang sudah selesai (completed)\n' +
                '• Keluhan yang sudah diselesaikan\n\n' +
                'Data dapat dikembalikan jika diperlukan.\n\n' +
                'Ketik "NONAKTIFKAN" untuk konfirmasi:')) {
        
        const confirmation = prompt('Ketik "NONAKTIFKAN" untuk konfirmasi:');
        if (confirmation === 'NONAKTIFKAN') {
            // Create form and submit
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `/admin/tenants/${tenantId}/delete`;
            
            // Add CSRF token
            const csrfToken = document.createElement('input');
            csrfToken.type = 'hidden';
            csrfToken.name = '_token';
            csrfToken.value = '<?php echo e(csrf_token()); ?>';
            form.appendChild(csrfToken);
            
            // Add method override
            const methodField = document.createElement('input');
            methodField.type = 'hidden';
            methodField.name = '_method';
            methodField.value = 'DELETE';
            form.appendChild(methodField);
            
            document.body.appendChild(form);
            form.submit();
        } else {
            alert('Tindakan dibatalkan.');
        }
    }
}


// Show success/error messages
<?php if(session('success')): ?>
    alert('<?php echo e(session('success')); ?>');
<?php endif; ?>

<?php if(session('error')): ?>
    alert('<?php echo e(session('error')); ?>');
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kosku-v2\resources\views/admin/tenants.blade.php ENDPATH**/ ?>