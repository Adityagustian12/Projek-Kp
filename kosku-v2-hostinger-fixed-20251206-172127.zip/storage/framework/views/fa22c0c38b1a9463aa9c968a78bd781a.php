<?php $__env->startSection('title', 'Form Booking - Kos-Kosan H.Kastim'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">
                        <i class="fas fa-calendar-plus me-2"></i>Form Booking Kamar
                    </h4>
                </div>
                <div class="card-body">
                    <!-- Room Info -->
                    <div class="alert alert-info">
                        <h5 class="alert-heading"><?php echo e($room->room_number); ?></h5>
                        <p class="mb-0">
                            <strong>Harga:</strong> Rp <?php echo e(number_format($room->price, 0, ',', '.')); ?>/bulan
                            <br>
                            <strong>Kapasitas:</strong> <?php echo e($room->capacity); ?> Orang
                        </p>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('seeker.bookings.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <input type="hidden" name="room_id" value="<?php echo e($room->id); ?>">

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="check_in_date" class="form-label">Tanggal Masuk</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['check_in_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="check_in_date" name="check_in_date" 
                                       value="<?php echo e(old('check_in_date')); ?>" required>
                            </div>
                        </div>

                        <!-- Data Diri Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fas fa-user me-2"></i>Data Diri
                                </h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="name" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="name" name="name" value="<?php echo e(old('name', auth()->user()->name ?? '')); ?>" 
                                               placeholder="Masukkan nama lengkap" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="email" name="email" value="<?php echo e(old('email', auth()->user()->email ?? '')); ?>" 
                                               placeholder="Masukkan email" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="phone" class="form-label">Nomor Telepon <span class="text-danger">*</span></label>
                                        <input type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="phone" name="phone" value="<?php echo e(old('phone', auth()->user()->phone ?? '')); ?>" 
                                               placeholder="Masukkan nomor telepon" required>
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="address" class="form-label">Alamat <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="address" name="address" value="<?php echo e(old('address', auth()->user()->address ?? '')); ?>" 
                                               placeholder="Masukkan alamat lengkap" required>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="documents" class="form-label">Upload KTP</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['documents.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="documents" name="documents[]" multiple 
                                   accept=".jpg,.jpeg,.png,.pdf" required>
                            <div class="form-text">
                                Upload KTP (JPG, PNG, PDF)
                            </div>
                        </div>

                        <!-- DP Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fas fa-wallet me-2"></i>Pembayaran DP
                                </h6>
                            </div>
                            <div class="card-body">
                                <div class="alert alert-secondary mb-3">
                                    <div class="d-flex align-items-start">
                                        <i class="fas fa-university me-3 mt-1"></i>
                                        <div class="w-100">
                                            <div class="fw-semibold mb-2">No. Rekening <span class="text-muted">(<?php echo e(config('app.bank.name')); ?>)</span></div>
                                            <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
                                                <span class="fs-5 fw-bold"><?php echo e(config('app.bank.account')); ?></span>
                                                <span class="badge bg-light text-dark"><?php echo e(config('app.bank.holder')); ?></span>
                                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="navigator.clipboard.writeText('<?php echo e(config('app.bank.account')); ?>')">
                                                    <i class="fas fa-copy me-1"></i>Salin
                                                </button>
                                            </div>
                                            <?php if(config('app.bank.note')): ?>
                                                <div class="small text-muted"><?php echo e(config('app.bank.note')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="alert alert-light border mb-3">
                                    <div class="fw-semibold mb-2"><i class="fas fa-mobile-alt me-2"></i>E-Wallet</div>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                            <div class="d-flex align-items-center gap-3">
                                                <span class="badge bg-info text-dark">DANA</span>
                                                <div class="d-flex flex-column">
                                                    <span class="fw-semibold"><?php echo e(config('app.ewallets.dana.number')); ?></span>
                                                    <small class="text-muted"><?php echo e(config('app.ewallets.dana.holder')); ?></small>
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="navigator.clipboard.writeText('<?php echo e(config('app.ewallets.dana.number')); ?>')">
                                                <i class="fas fa-copy me-1"></i>Salin
                                            </button>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                            <div class="d-flex align-items-center gap-3">
                                                <span class="badge bg-success">GoPay</span>
                                                <div class="d-flex flex-column">
                                                    <span class="fw-semibold"><?php echo e(config('app.ewallets.gopay.number')); ?></span>
                                                    <small class="text-muted"><?php echo e(config('app.ewallets.gopay.holder')); ?></small>
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="navigator.clipboard.writeText('<?php echo e(config('app.ewallets.gopay.number')); ?>')">
                                                <i class="fas fa-copy me-1"></i>Salin
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                                <div class="mb-3">
                                    <label for="amount" class="form-label">Nominal DP <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="number" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="amount" name="amount" min="200000" step="1000" 
                                               value="<?php echo e(old('amount', 200000)); ?>" required>
                                    </div>
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Minimal Rp 200.000</div>
                                </div>

                                <div class="mb-3">
                                    <label for="payment_proof" class="form-label">Bukti Pembayaran DP <span class="text-danger">*</span></label>
                                    <input type="file" class="form-control <?php $__errorArgs = ['payment_proof'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="payment_proof" name="payment_proof" accept="image/*,.pdf" required>
                                    <?php $__errorArgs = ['payment_proof'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Format: JPG, PNG, PDF. Maks 2MB.</div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="notes" class="form-label">Catatan Tambahan</label>
                            <textarea class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      id="notes" name="notes" rows="3" 
                                      placeholder="Catatan tambahan untuk admin..."><?php echo e(old('notes')); ?></textarea>
                        </div>

                        

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="<?php echo e(route('public.room.detail', $room)); ?>" class="btn btn-outline-secondary me-md-2">
                                <i class="fas fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-calendar-plus me-2"></i>Submit Booking
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Set minimum date to tomorrow
    document.addEventListener('DOMContentLoaded', function() {
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const checkInDate = document.getElementById('check_in_date');
        
        checkInDate.min = tomorrow.toISOString().split('T')[0];
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kosku-v2\resources\views/public/booking-form.blade.php ENDPATH**/ ?>