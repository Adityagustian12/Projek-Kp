<?php $__env->startSection('title', 'Dashboard Penghuni - Kos-Kosan H.Kastim'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar">
            <div class="p-3">
                <h6 class="text-muted text-uppercase mb-3">Menu Penghuni</h6>
                <nav class="nav flex-column">
                    <a class="nav-link active" href="<?php echo e(route('tenant.dashboard')); ?>">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="<?php echo e(route('tenant.bills')); ?>">
                        <i class="fas fa-file-invoice me-2"></i>Tagihan
                    </a>
                    <a class="nav-link" href="<?php echo e(route('tenant.complaints')); ?>">
                        <i class="fas fa-exclamation-triangle me-2"></i>Komplain
                    </a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10 main-content">
            <div class="p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="mb-0">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard Penghuni
                    </h2>
                    <span class="badge bg-success fs-6">Selamat datang, <?php echo e(auth()->user()->name); ?></span>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-3">
                        <div class="card bg-warning text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="mb-0"><?php echo e($stats['pending_bills']); ?></h4>
                                        <p class="mb-0">Tagihan Belum Lunas</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-file-invoice fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-3">
                        <div class="card bg-danger text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="mb-0"><?php echo e($stats['overdue_bills']); ?></h4>
                                        <p class="mb-0">Tagihan Jatuh Tempo</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-exclamation-circle fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-3">
                        <div class="card bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="mb-0"><?php echo e($stats['active_complaints']); ?></h4>
                                        <p class="mb-0">Komplain Aktif</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-exclamation-triangle fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-3">
                        <div class="card bg-secondary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
<div>
                                        <h4 class="mb-0"><?php echo e($stats['pending_payments']); ?></h4>
                                        <p class="mb-0">Pembayaran Menunggu</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-credit-card fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activities -->
                <div class="row">
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <i class="fas fa-file-invoice me-2"></i>Tagihan Terbaru
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php $__empty_1 = true; $__currentLoopData = $recent_bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="flex-shrink-0">
                                            <i class="fas fa-file-invoice-dollar fa-2x text-primary"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1">Tagihan <?php echo e($bill->month); ?>/<?php echo e($bill->year); ?></h6>
                                            <p class="mb-1 text-muted">Rp <?php echo e(number_format($bill->total_amount, 0, ',', '.')); ?></p>
                                            <small class="text-muted">Jatuh tempo: <?php echo e($bill->due_date->format('d M Y')); ?></small>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <?php if($bill->status === 'paid'): ?>
                                                <span class="badge bg-success">Lunas</span>
                                            <?php elseif($bill->status === 'overdue'): ?>
                                                <span class="badge bg-danger">Jatuh Tempo</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning">Belum Lunas</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-muted text-center">Tidak ada tagihan</p>
                                <?php endif; ?>
                                
                                <?php if($recent_bills->count() > 0): ?>
                                    <div class="text-center">
                                        <a href="<?php echo e(route('tenant.bills')); ?>" class="btn btn-outline-primary btn-sm">
                                            Lihat Semua Tagihan
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <i class="fas fa-exclamation-triangle me-2"></i>Komplain Terbaru
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php $__empty_1 = true; $__currentLoopData = $recent_complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="flex-shrink-0">
                                            <i class="fas fa-exclamation-circle fa-2x text-warning"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1"><?php echo e($complaint->title); ?></h6>
                                            <p class="mb-1 text-muted"><?php echo e($complaint->category); ?></p>
                                            <small class="text-muted"><?php echo e($complaint->created_at->diffForHumans()); ?></small>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="badge bg-<?php echo e($complaint->status === 'new' ? 'danger' : ($complaint->status === 'in_progress' ? 'warning' : 'success')); ?>">
                                                <?php echo e($complaint->getStatusLabel()); ?>

                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-muted text-center">Tidak ada komplain</p>
                                <?php endif; ?>
                                
                                <?php if($recent_complaints->count() > 0): ?>
                                    <div class="text-center">
                                        <a href="<?php echo e(route('tenant.complaints')); ?>" class="btn btn-outline-warning btn-sm">
                                            Lihat Semua Komplain
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kosku-v2\resources\views/tenant/dashboard.blade.php ENDPATH**/ ?>