

<?php $__env->startSection('title', 'Detail Kamar - Kos-Kosan H.Kastim'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 mt-md-5">
    

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h2 class="card-title mb-3"><?php echo e($room->room_number); ?></h2>
                    
                    <?php if($room->images && count($room->images) > 0): ?>
                        <div class="mb-3">
                            <div class="row g-2">
                                <?php $__currentLoopData = $room->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-md-4">
                                        <img src="<?php echo e(asset('storage/' . $image)); ?>" 
                                             class="img-fluid rounded shadow-sm" 
                                             alt="Room <?php echo e($room->room_number); ?>"
                                             style="height: 180px; width: 100%; object-fit: cover;">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mb-4 bg-light p-5 text-center rounded">
                            <i class="fas fa-image fa-4x text-muted"></i>
                            <p class="text-muted mt-2">Tidak ada gambar tersedia</p>
                        </div>
                    <?php endif; ?>

                    <h5 class="mb-2">Deskripsi</h5>
                    <p class="text-muted mb-0"><?php echo e($room->description ?: 'Tidak ada deskripsi tersedia.'); ?></p>

                    
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm sticky-top" style="top: 84px;">
                <div class="card-body">
                    <h4 class="card-title mb-3">Informasi Kamar</h4>
                    
                    <div class="mb-3">
                        <strong>Nomor Kamar:</strong>
                        <span class="text-muted"><?php echo e($room->room_number); ?></span>
                    </div>
                    
                    
                    <div class="mb-3">
                        <strong>Kapasitas:</strong>
                        <span class="text-muted"><?php echo e($room->capacity); ?> Orang</span>
                    </div>
                    
                    
                    <?php if($room->area): ?>
                        <div class="mb-3">
                            <strong>Luas:</strong>
                            <span class="text-muted"><?php echo e($room->area); ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-4">
                        <strong>Status:</strong>
                        <?php
                            $statusClass = $room->status === 'available' ? 'success' : ($room->status === 'occupied' ? 'warning' : 'danger');
                            $statusLabel = $room->status === 'available' ? 'Tersedia' : ($room->status === 'occupied' ? 'Terisi' : 'Perawatan');
                        ?>
                        <span class="badge bg-<?php echo e($statusClass); ?> ms-2"><?php echo e($statusLabel); ?></span>
                    </div>

                    <hr>

                    <div class="text-center mb-4">
                        <h3 class="text-primary">Rp <?php echo e(number_format($room->price, 0, ',', '.')); ?></h3>
                        <small class="text-muted">per bulan</small>
                    </div>

                    <div class="d-grid gap-2">
                        <?php if($room->status === 'available'): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(auth()->user()->isSeeker() || auth()->user()->isTenant()): ?>
                                    <a href="<?php echo e(route('seeker.booking.form', $room)); ?>" class="btn btn-primary btn-lg">
                                        <i class="fas fa-calendar-plus me-2"></i>Booking Sekarang
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('seeker.booking.form', $room)); ?>" class="btn btn-primary btn-lg">
                                    <i class="fas fa-sign-in-alt me-2"></i>Booking Sekarang
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <button class="btn btn-secondary btn-lg" disabled>
                                <i class="fas fa-ban me-2"></i>Tidak Tersedia
                            </button>
                        <?php endif; ?>

                        <a href="<?php echo e(route('public.home')); ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Kembali ke Beranda
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kosku-v2\resources\views/public/room-detail.blade.php ENDPATH**/ ?>