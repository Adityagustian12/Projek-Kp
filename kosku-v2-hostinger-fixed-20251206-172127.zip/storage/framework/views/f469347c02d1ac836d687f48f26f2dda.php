

<?php $__env->startSection('title', 'Booking Saya - Pencari Kosan Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar">
            <div class="p-3">
                <h6 class="text-muted text-uppercase mb-3">Menu Pencari Kosan</h6>
                <nav class="nav flex-column">
                    <a class="nav-link" href="<?php echo e(route('seeker.dashboard')); ?>">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link active" href="<?php echo e(route('bookings.my')); ?>">
                        <i class="fas fa-calendar-check me-2"></i>Booking Saya
                    </a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10 main-content">
            <div class="p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="mb-0">
                        <i class="fas fa-calendar-check me-2"></i>Booking Saya
                    </h2>
                    <a href="<?php echo e(route('public.home')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Booking Baru
                    </a>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Bookings Table -->
                <div class="card">
                    <div class="card-body">
                        <?php if($bookings->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Kamar</th>
                                            <th>Tanggal Masuk</th>
                                            <th>Status</th>
                                            <th>Tanggal Booking</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($booking->id); ?></td>
                                                <td>
                                                    <div>
                                                        <strong><?php echo e($booking->room->room_number); ?></strong>
                                                        <br>
                                                        <small class="text-muted"><?php echo e($booking->room->description); ?></small>
                                                    </div>
                                                </td>
                                                <td><?php echo e($booking->move_in_date ? $booking->move_in_date->format('d/m/Y') : '-'); ?></td>
                                                <td>
                                                    <?php switch($booking->status):
                                                        case ('pending'): ?>
                                                            <span class="badge bg-warning">Menunggu Konfirmasi</span>
                                                            <?php break; ?>
                                                        <?php case ('confirmed'): ?>
                                                            <span class="badge bg-info">Dikonfirmasi</span>
                                                            <?php break; ?>
                                                        <?php case ('occupied'): ?>
                                                            <span class="badge bg-success">Sudah Masuk</span>
                                                            <?php break; ?>
                                                        <?php case ('rejected'): ?>
                                                            <span class="badge bg-danger">Ditolak</span>
                                                            <?php break; ?>
                                                        <?php case ('completed'): ?>
                                                            <span class="badge bg-secondary">Selesai</span>
                                                            <?php break; ?>
                                                        <?php default: ?>
                                                            <span class="badge bg-secondary"><?php echo e(ucfirst($booking->status)); ?></span>
                                                    <?php endswitch; ?>
                                                </td>
                                                <td><?php echo e($booking->created_at->format('d/m/Y H:i')); ?></td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <a href="<?php echo e(route('bookings.show', $booking)); ?>" 
                                                           class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-eye"></i> Detail
                                                        </a>
                                                        
                                                        <?php if($booking->status === 'pending'): ?>
                                                            <a href="<?php echo e(route('seeker.bookings.dp-payment', $booking)); ?>" 
                                                               class="btn btn-sm btn-success">
                                                                <i class="fas fa-money-bill-wave"></i> Lunasi DP
                                                            </a>
                                                            <form action="<?php echo e(route('bookings.cancel', $booking)); ?>" 
                                                                  method="POST" class="d-inline"
                                                                  onsubmit="return confirm('Apakah Anda yakin ingin membatalkan booking ini?')">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                                                    <i class="fas fa-times"></i> Batal
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination -->
                            <div class="d-flex justify-content-center mt-4">
                                <?php echo e($bookings->links()); ?>

                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-calendar-times fa-4x text-muted mb-3"></i>
                                <h4 class="text-muted">Belum Ada Booking</h4>
                                <p class="text-muted">Anda belum melakukan booking kamar kos.</p>
                                <a href="<?php echo e(route('public.home')); ?>" class="btn btn-primary">
                                    <i class="fas fa-plus me-2"></i>Booking Kamar Sekarang
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kosku-v2\resources\views/seeker/bookings.blade.php ENDPATH**/ ?>