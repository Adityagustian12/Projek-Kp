# Instruksi Deploy ke Hostinger

## File ZIP ini sudah disiapkan khusus untuk Hostinger

### Struktur yang sudah disertakan:
- ✓ composer.json (untuk deteksi Laravel)
- ✓ artisan (Laravel CLI)
- ✓ .htaccess (redirect ke public)
- ✓ Folder app/, config/, database/, public/, resources/, routes/, storage/
- ✓ Semua file penting Laravel

### Langkah-langkah setelah upload:

1. Extract file ZIP di public_html
2. Install dependencies:
   composer install --no-dev --optimize-autoloader
   npm install && npm run build

3. Buat file .env:
   cp .env.example .env
   (edit dengan database Hostinger)

4. Generate key:
   php artisan key:generate

5. Run migrations:
   php artisan migrate --force

6. Create storage link:
   php artisan storage:link

7. Set permissions:
   chmod -R 755 storage bootstrap/cache

8. Optimize:
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache