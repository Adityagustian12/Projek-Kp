# Instruksi Deploy ke Hostinger

## Langkah-langkah:

1. **Upload file ZIP ini ke Hostinger cPanel**
   - Gunakan fitur "Upload Backup" di Hostinger
   - Atau extract di local, lalu upload via FTP/File Manager

2. **Extract file ZIP di server**
   - Extract di folder `public_html` atau folder yang ditentukan

3. **Install Dependencies**
   ```bash
   composer install --no-dev --optimize-autoloader
   npm install
   npm run build
   ```

4. **Setup Environment**
   - Copy `.env.example` ke `.env`
   - Edit `.env` dengan konfigurasi database Hostinger:
     ```
     DB_CONNECTION=mysql
     DB_HOST=localhost
     DB_PORT=3306
     DB_DATABASE=nama_database_dari_cpanel
     DB_USERNAME=username_database_dari_cpanel
     DB_PASSWORD=password_database_dari_cpanel
     ```

5. **Generate App Key**
   ```bash
   php artisan key:generate
   ```

6. **Run Migrations**
   ```bash
   php artisan migrate --force
   ```

7. **Create Storage Link**
   ```bash
   php artisan storage:link
   ```

8. **Set Permissions**
   ```bash
   chmod -R 755 storage
   chmod -R 755 bootstrap/cache
   ```

9. **Optimize**
   ```bash
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   ```

10. **Point Document Root**
    - Di cPanel, pastikan document root mengarah ke folder `public`
    - Atau buat `.htaccess` di root yang redirect ke `public`

## Catatan:
- Pastikan PHP version >= 8.2
- Pastikan extension PHP yang diperlukan sudah aktif
- File `.env` tidak termasuk dalam ZIP untuk keamanan